static const unsigned short ROUTER_PORT = 32000;
static const unsigned short BANK_PORT = 32001;
static const unsigned short ATM_PORT = 32002;
