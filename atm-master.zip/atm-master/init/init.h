/* ------------------------------------------------------------------
   Robert Nash
   Joseph
   Nick
   Nischay Modi

   University of Maryland, CMSC414, Fall 2019

------------------------------------------------------------------ */


#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>

#define INCORRECT_ARGS  62
#define FILE_EXISTS     63
#define PROGRAM_FAILED  64